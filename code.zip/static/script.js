/**
 * 图像水印隐藏系统 — 前端交互逻辑 (改进版)
 */

// ═══════════════════════════════════════════════════════════
//  方法参数配置
// ═══════════════════════════════════════════════════════════
const METHOD_CONFIG = {
    qim:    { name: 'QIM-LL 小波盲水印', paramLabel: '量化步长 δ', min: 8,  max: 48, step: 2, default: 20, unit: '越大越鲁棒' },
    chroma: { name: '色度通道水印',      paramLabel: '量化步长 δ', min: 4,  max: 32, step: 2, default: 12, unit: '极隐蔽' },
    dct:    { name: '分块DCT水印',       paramLabel: '量化步长',   min: 10, max: 80, step: 2, default: 30, unit: '' },
    svd:    { name: 'SVD奇异值水印',     paramLabel: '嵌入强度 α', min: 0.01, max: 0.10, step: 0.01, default: 0.02, unit: '' }
};

let currentMethod = 'qim';
// 记住每个方法最后一次设置的参数值
const savedParams = {};

// ═══════════════════════════════════════════════════════════
//  Tab 切换
// ═══════════════════════════════════════════════════════════
document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', () => {
        document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
        document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
        tab.classList.add('active');
        document.getElementById(`tab-${tab.dataset.tab}`).classList.add('active');
    });
});

// ═══════════════════════════════════════════════════════════
//  方法选择 → 更新滑块参数 (保留用户设置的值)
// ═══════════════════════════════════════════════════════════
function updateParamSlider(resetToDefault = false) {
    const method = document.querySelector('input[name="method"]:checked')?.value || 'qim';
    const prevMethod = currentMethod;

    // 保存当前方法的参数值
    const slider = document.getElementById('paramSlider');
    if (prevMethod && !resetToDefault) {
        savedParams[prevMethod] = parseFloat(slider.value);
    }

    currentMethod = method;
    const cfg = METHOD_CONFIG[method];

    // 更新滑块范围
    slider.min = cfg.min;
    slider.max = cfg.max;
    slider.step = cfg.step;

    // 恢复之前保存的值，否则用默认值
    const newValue = savedParams[method] !== undefined ? savedParams[method] : cfg.default;
    slider.value = newValue;

    // 更新显示
    updateSliderDisplay(method, newValue);
}

function updateSliderDisplay(method, value) {
    const cfg = METHOD_CONFIG[method];
    document.getElementById('paramValue').textContent = value;
    document.getElementById('paramUnit').textContent = cfg.paramLabel ? `(${cfg.paramLabel})` : '';
}

// 滑块拖动时实时更新显示
document.getElementById('paramSlider').addEventListener('input', function() {
    updateSliderDisplay(currentMethod, this.value);
});

// 监听方法切换 (只有用户手动切换时才触发)
document.querySelectorAll('input[name="method"]').forEach(radio => {
    radio.addEventListener('change', () => updateParamSlider(false));
});

// 初始化 (首次加载用默认值)
updateParamSlider(true);

// ═══════════════════════════════════════════════════════════
//  拖拽上传通用逻辑
// ═══════════════════════════════════════════════════════════
function setupDropzone(dropzoneId, inputId, previewId, onReady) {
    const dropzone = document.getElementById(dropzoneId);
    const input = document.getElementById(inputId);
    const preview = document.getElementById(previewId);

    dropzone.addEventListener('click', () => input.click());

    input.addEventListener('change', () => {
        if (input.files.length > 0) {
            showPreview(input.files[0], preview, dropzone);
            if (onReady) onReady();
        }
    });

    dropzone.addEventListener('dragover', e => {
        e.preventDefault();
        dropzone.classList.add('drag-over');
    });
    dropzone.addEventListener('dragleave', () => dropzone.classList.remove('drag-over'));
    dropzone.addEventListener('drop', e => {
        e.preventDefault();
        dropzone.classList.remove('drag-over');
        if (e.dataTransfer.files.length > 0) {
            input.files = e.dataTransfer.files;
            showPreview(e.dataTransfer.files[0], preview, dropzone);
            if (onReady) onReady();
        }
    });
}

function showPreview(file, imgEl, dropzone) {
    const reader = new FileReader();
    reader.onload = e => {
        imgEl.src = e.target.result;
        imgEl.style.display = 'block';
        const content = dropzone.querySelector('.dropzone-content');
        if (content) content.style.display = 'none';
    };
    reader.readAsDataURL(file);
}

// ═══════════════════════════════════════════════════════════
//  Tab 1: 图像隐藏
// ═══════════════════════════════════════════════════════════
const coverInput = document.getElementById('coverInput');
const secretInput = document.getElementById('secretInput');
const btnHide = document.getElementById('btnHide');

function checkHideReady() {
    btnHide.disabled = !(coverInput.files.length > 0 && secretInput.files.length > 0);
}

setupDropzone('coverDropzone', 'coverInput', 'coverPreview', checkHideReady);
setupDropzone('secretDropzone', 'secretInput', 'secretPreview', checkHideReady);

const paramSlider = document.getElementById('paramSlider');
const paramValue = document.getElementById('paramValue');
paramSlider.addEventListener('input', () => {
    paramValue.textContent = paramSlider.value;
});

btnHide.addEventListener('click', async () => {
    const formData = new FormData();
    formData.append('cover', coverInput.files[0]);
    formData.append('secret', secretInput.files[0]);
    formData.append('method', currentMethod);
    formData.append('param', paramSlider.value);

    btnHide.disabled = true;
    btnHide.textContent = '⏳ 处理中...';

    try {
        const resp = await fetch('/api/hide', { method: 'POST', body: formData });
        const data = await resp.json();
        if (data.error) { alert('错误: ' + data.error); return; }

        document.getElementById('hideResults').style.display = 'block';
        document.getElementById('hidePsnr').textContent = data.metrics.psnr + ' dB';
        document.getElementById('hideSsim').textContent = data.metrics.ssim;
        document.getElementById('hideNcc').textContent = data.metrics.ncc;
        document.getElementById('hideBlind').textContent = data.metrics.blind ? '盲提取' : '需原图';
        document.getElementById('hideBlind').style.color = data.metrics.blind ? '#22c55e' : '#f59e0b';
        document.getElementById('hideTime').textContent = data.metrics.elapsed_ms + ' ms';
        document.getElementById('containerImg').src = data.container;
        document.getElementById('diffImg').src = data.diff_map;
        document.getElementById('extractedImg').src = data.extracted;

        document.getElementById('hideResults').scrollIntoView({ behavior: 'smooth' });
    } catch (err) {
        alert('请求失败: ' + err.message);
    } finally {
        btnHide.disabled = false;
        btnHide.textContent = '🚀 开始隐藏';
    }
});

// ═══════════════════════════════════════════════════════════
//  Tab 2: 攻击测试
// ═══════════════════════════════════════════════════════════
const attackInput = document.getElementById('attackInput');
const btnAttack = document.getElementById('btnAttack');

setupDropzone('attackDropzone', 'attackInput', 'attackPreview', () => {
    btnAttack.disabled = false;
});

btnAttack.addEventListener('click', async () => {
    const selected = [];
    document.querySelectorAll('#tab-attack input[type="checkbox"]:checked').forEach(cb => {
        selected.push(cb.value);
    });
    if (selected.length === 0) { alert('请至少选择一种攻击方式'); return; }

    const formData = new FormData();
    formData.append('image', attackInput.files[0]);
    formData.append('attacks', selected.join(','));

    btnAttack.disabled = true;
    btnAttack.textContent = '⏳ 攻击中...';

    try {
        const resp = await fetch('/api/attack', { method: 'POST', body: formData });
        const data = await resp.json();
        if (data.error) { alert('错误: ' + data.error); return; }

        document.getElementById('attackResults').style.display = 'block';
        const grid = document.getElementById('attackGrid');
        grid.innerHTML = '';

        for (const [key, attack] of Object.entries(data.attacks)) {
            const card = document.createElement('div');
            card.className = 'attack-result-card';
            card.innerHTML = `
                <h4>${attack.name}</h4>
                <img src="${attack.image}" alt="${attack.name}">
                <div class="attack-metrics">
                    <span>PSNR: ${attack.psnr} dB</span>
                    <span>SSIM: ${attack.ssim}</span>
                </div>`;
            grid.appendChild(card);
        }
        document.getElementById('attackResults').scrollIntoView({ behavior: 'smooth' });
    } catch (err) {
        alert('请求失败: ' + err.message);
    } finally {
        btnAttack.disabled = false;
        btnAttack.textContent = '⚔️ 开始攻击';
    }
});

// ═══════════════════════════════════════════════════════════
//  Tab 3: 完整流水线
// ═══════════════════════════════════════════════════════════
const pipeCoverInput = document.getElementById('pipeCoverInput');
const pipeSecretInput = document.getElementById('pipeSecretInput');
const btnPipeline = document.getElementById('btnPipeline');

function checkPipeReady() {
    btnPipeline.disabled = !(pipeCoverInput.files.length > 0 && pipeSecretInput.files.length > 0);
}

setupDropzone('pipeCoverDropzone', 'pipeCoverInput', 'pipeCoverPreview', checkPipeReady);
setupDropzone('pipeSecretDropzone', 'pipeSecretInput', 'pipeSecretPreview', checkPipeReady);

btnPipeline.addEventListener('click', async () => {
    const formData = new FormData();
    formData.append('cover', pipeCoverInput.files[0]);
    formData.append('secret', pipeSecretInput.files[0]);
    formData.append('method', currentMethod);
    formData.append('param', document.getElementById('paramSlider').value);

    btnPipeline.disabled = true;
    document.getElementById('pipelineLoading').style.display = 'block';
    document.getElementById('pipelineResults').style.display = 'none';

    try {
        const resp = await fetch('/api/full-pipeline', { method: 'POST', body: formData });
        const data = await resp.json();
        if (data.error) { alert('错误: ' + data.error); return; }

        document.getElementById('pipelineLoading').style.display = 'none';
        document.getElementById('pipelineResults').style.display = 'block';

        document.getElementById('pipePsnr').textContent = data.hide_metrics.psnr + ' dB';
        document.getElementById('pipeSsim').textContent = data.hide_metrics.ssim;
        document.getElementById('pipeContainer').src = data.container;
        document.getElementById('pipeDiff').src = data.diff_map;

        const grid = document.getElementById('pipelineAttackGrid');
        grid.innerHTML = '';

        // 按 NCC 降序排列
        const entries = Object.entries(data.attack_results)
            .sort((a, b) => b[1].ncc - a[1].ncc);

        for (const [key, result] of entries) {
            let nccClass = 'ncc-badge';
            if (result.ncc < 0.3) nccClass += ' fail';
            else if (result.ncc < 0.7) nccClass += ' warn';

            const card = document.createElement('div');
            card.className = 'pipeline-card';
            card.innerHTML = `
                <h4>${result.name}</h4>
                <div class="card-images">
                    <div>
                        <span class="label">被攻击图</span>
                        <img src="${result.attacked_image}">
                    </div>
                    <div>
                        <span class="label">提取结果</span>
                        <img src="${result.extracted}">
                    </div>
                </div>
                <div class="pipeline-metrics">
                    <span>NCC: <span class="${nccClass}">${result.ncc}</span></span>
                    <span>图PSNR: ${result.attacked_psnr} dB</span>
                </div>`;
            grid.appendChild(card);
        }

        document.getElementById('pipelineResults').scrollIntoView({ behavior: 'smooth' });
    } catch (err) {
        alert('请求失败: ' + err.message);
    } finally {
        btnPipeline.disabled = false;
        document.getElementById('pipelineLoading').style.display = 'none';
    }
});

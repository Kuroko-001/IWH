"""
攻击模拟模块 — 测试水印鲁棒性
"""
import cv2
import numpy as np
from scipy.ndimage import rotate


def gaussian_noise(image: np.ndarray, sigma: float = 10.0) -> np.ndarray:
    """高斯噪声攻击"""
    noise = np.random.randn(*image.shape).astype(np.float32) * sigma
    noisy = image.astype(np.float32) + noise
    return np.clip(noisy, 0, 255).astype(np.uint8)


def salt_pepper_noise(image: np.ndarray, amount: float = 0.02) -> np.ndarray:
    """椒盐噪声攻击"""
    result = image.copy()
    h, w = image.shape[:2]
    num_pixels = int(h * w * amount)

    # 盐噪声 (白色)
    coords = [np.random.randint(0, i - 1, num_pixels) for i in (h, w)]
    result[coords[0], coords[1]] = 255

    # 椒噪声 (黑色)
    coords = [np.random.randint(0, i - 1, num_pixels) for i in (h, w)]
    result[coords[0], coords[1]] = 0

    return result


def jpeg_compression(image: np.ndarray, quality: int = 50) -> np.ndarray:
    """JPEG 压缩攻击"""
    encode_param = [int(cv2.IMWRITE_JPEG_QUALITY), quality]
    _, encoded = cv2.imencode('.jpg', image, encode_param)
    return cv2.imdecode(encoded, cv2.IMREAD_COLOR)


def rotation_attack(image: np.ndarray, angle: float = 10.0) -> np.ndarray:
    """旋转攻击（带自动裁剪）"""
    if image.ndim == 3:
        result = np.zeros_like(image)
        for c in range(3):
            result[:, :, c] = rotate(image[:, :, c], angle, reshape=False, mode='reflect')
        return result
    return rotate(image, angle, reshape=False, mode='reflect')


def scaling_attack(image: np.ndarray, scale: float = 0.8) -> np.ndarray:
    """缩放攻击 — 缩小再放大回原尺寸"""
    h, w = image.shape[:2]
    new_h, new_w = int(h * scale), int(w * scale)
    scaled = cv2.resize(image, (new_w, new_h), interpolation=cv2.INTER_LINEAR)
    return cv2.resize(scaled, (w, h), interpolation=cv2.INTER_LINEAR)


def cropping_attack(image: np.ndarray, crop_ratio: float = 0.2) -> np.ndarray:
    """裁剪攻击 — 随机裁剪一部分并用黑色填充"""
    h, w = image.shape[:2]
    crop_h = int(h * crop_ratio)
    crop_w = int(w * crop_ratio)
    result = image.copy()
    start_h = np.random.randint(0, h - crop_h)
    start_w = np.random.randint(0, w - crop_w)
    result[start_h:start_h + crop_h, start_w:start_w + crop_w] = 0
    return result


def brightness_attack(image: np.ndarray, delta: float = 30.0) -> np.ndarray:
    """亮度调整攻击"""
    result = image.astype(np.float32) + delta
    return np.clip(result, 0, 255).astype(np.uint8)


def median_filter_attack(image: np.ndarray, kernel_size: int = 3) -> np.ndarray:
    """中值滤波攻击"""
    if image.ndim == 3:
        return cv2.medianBlur(image, kernel_size)
    return cv2.medianBlur(image, kernel_size)


ATTACKS = {
    'gaussian_noise': ('高斯噪声 (σ=10)', gaussian_noise),
    'salt_pepper': ('椒盐噪声 (2%)', lambda img: salt_pepper_noise(img, 0.02)),
    'jpeg_50': ('JPEG压缩 (Q=50)', lambda img: jpeg_compression(img, 50)),
    'jpeg_30': ('JPEG压缩 (Q=30)', lambda img: jpeg_compression(img, 30)),
    'rotation': ('旋转攻击 (10°)', lambda img: rotation_attack(img, 10)),
    'scaling': ('缩放攻击 (0.8×)', lambda img: scaling_attack(img, 0.8)),
    'cropping': ('裁剪攻击 (20%)', lambda img: cropping_attack(img, 0.2)),
    'brightness': ('亮度调整 (+30)', lambda img: brightness_attack(img, 30)),
    'median_filter': ('中值滤波 (3×3)', lambda img: median_filter_attack(img, 3)),
}

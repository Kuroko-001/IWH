"""
图像水印与隐藏系统 — Flask 后端 v3
"""
import os
import time
import base64
import traceback

import cv2
import numpy as np
from flask import Flask, render_template, request, jsonify

from watermark import (
    embed_qim_ll, extract_qim_ll,
    embed_chroma_qim, extract_chroma_qim,
    embed_dct_full, extract_dct_full,
    embed_svd, extract_svd,
    calculate_psnr, calculate_ssim, calculate_ncc
)
from attacks import ATTACKS

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 32 * 1024 * 1024
app.config['UPLOAD_FOLDER'] = os.path.join(os.path.dirname(__file__), 'uploads')
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)


# ── 工具函数 ──────────────────────────────────────────────

def _read_img(key, form_key=None):
    """从 files 或 form b64 读取图像"""
    if key in request.files:
        buf = request.files[key].read()
        return cv2.imdecode(np.frombuffer(buf, np.uint8), cv2.IMREAD_COLOR)
    k = form_key or f'{key}_b64'
    if request.form.get(k):
        data = base64.b64decode(request.form[k])
        return cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_COLOR)
    return None


def _to_b64(img: np.ndarray) -> str:
    """numpy → PNG data URL"""
    _, buf = cv2.imencode('.png', img)
    return f'data:image/png;base64,{base64.b64encode(buf).decode()}'


def _upscale(img: np.ndarray, target_shape: tuple) -> np.ndarray:
    """放大到目标尺寸用于显示"""
    if img.shape[:2] != target_shape[:2]:
        return cv2.resize(img, (target_shape[1], target_shape[0]),
                          interpolation=cv2.INTER_NEAREST)
    return img


# ── 嵌入/提取 统一调度 ────────────────────────────────────

EMBEDDERS = {
    'qim':    (embed_qim_ll,    extract_qim_ll,    True),
    'chroma': (embed_chroma_qim, extract_chroma_qim, True),
    'dct':    (embed_dct_full,  extract_dct_full,  True),
    'svd':    (embed_svd,       extract_svd,       False),
}

DEFAULT_PARAMS = {'qim': 20.0, 'chroma': 12.0, 'dct': 30.0, 'svd': 0.02}


def do_embed_extract(cover, secret, method, param):
    """返回 (container, extracted_raw, is_blind)"""
    secret_gray = cv2.cvtColor(secret, cv2.COLOR_BGR2GRAY)
    embed_fn, extract_fn, is_blind = EMBEDDERS[method]

    container = embed_fn(cover, secret_gray, param)
    if is_blind:
        extracted = extract_fn(container, secret_gray.shape, param)
    else:
        extracted = extract_fn(cover, container, secret_gray.shape, param)

    return container, extracted, is_blind


# ── API 路由 ──────────────────────────────────────────────

@app.route('/')
def index():
    return render_template('index.html')


@app.route('/api/hide', methods=['POST'])
def hide_image():
    try:
        cover = _read_img('cover')
        secret = _read_img('secret')
        if cover is None: return jsonify({'error': '缺少封面图像'}), 400
        if secret is None: return jsonify({'error': '缺少秘密图像'}), 400

        method = request.form.get('method', 'qim')
        param = float(request.form.get('param', DEFAULT_PARAMS.get(method, 24.0)))
        secret = cv2.resize(secret, (cover.shape[1], cover.shape[0]))

        t0 = time.time()
        container, extracted_raw, is_blind = do_embed_extract(cover, secret, method, param)
        elapsed = round((time.time() - t0) * 1000, 1)

        # 指标: NCC 在原生提取分辨率下计算
        secret_gray = cv2.cvtColor(secret, cv2.COLOR_BGR2GRAY)
        ncc_val = calculate_ncc(secret_gray, extracted_raw)

        # 显示用: 放大提取结果到原图尺寸
        extracted_display = _upscale(extracted_raw, cover.shape)

        psnr_val = calculate_psnr(cover, container)
        ssim_val = calculate_ssim(cover, container)

        diff = cv2.absdiff(cover.astype(np.float32), container.astype(np.float32))
        diff = (diff * 20).clip(0, 255).astype(np.uint8)

        return jsonify({
            'success': True,
            'container': _to_b64(container),
            'extracted': _to_b64(extracted_display),
            'diff_map': _to_b64(diff),
            'metrics': {
                'psnr': round(psnr_val, 2),
                'ssim': round(ssim_val, 4),
                'ncc': round(ncc_val, 4),
                'elapsed_ms': elapsed,
                'blind': is_blind
            }
        })
    except Exception as e:
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500


@app.route('/api/attack', methods=['POST'])
def attack_image():
    try:
        image = _read_img('image')
        if image is None: return jsonify({'error': '缺少图像'}), 400

        attrs = request.form.get('attacks', '')
        att_list = [a.strip() for a in attrs.split(',') if a.strip() in ATTACKS]

        results = {}
        for ak in att_list:
            name, fn = ATTACKS[ak]
            attacked = fn(image)
            results[ak] = {
                'name': name,
                'image': _to_b64(attacked),
                'psnr': round(calculate_psnr(image, attacked), 2),
                'ssim': round(calculate_ssim(image, attacked), 4)
            }
        return jsonify({'success': True, 'attacks': results})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/full-pipeline', methods=['POST'])
def full_pipeline():
    try:
        cover = _read_img('cover')
        secret = _read_img('secret')
        if cover is None or secret is None:
            return jsonify({'error': '缺少封面或秘密图像'}), 400

        method = request.form.get('method', 'qim')
        param = float(request.form.get('param', DEFAULT_PARAMS.get(method, 24.0)))
        secret = cv2.resize(secret, (cover.shape[1], cover.shape[0]))
        secret_gray = cv2.cvtColor(secret, cv2.COLOR_BGR2GRAY)

        # 嵌入
        container, extracted_raw, is_blind = do_embed_extract(cover, secret, method, param)

        hide_psnr = calculate_psnr(cover, container)
        hide_ssim = calculate_ssim(cover, container)
        ncc_before = calculate_ncc(secret_gray, extracted_raw)

        # 攻击 + 提取
        embed_fn, extract_fn, is_blind = EMBEDDERS[method]
        attack_results = {}
        for ak, (aname, afn) in ATTACKS.items():
            attacked = afn(container)

            if is_blind:
                ext = extract_fn(attacked, secret_gray.shape, param)
            else:
                ext = extract_fn(cover, attacked, secret_gray.shape, param)

            ncc_val = calculate_ncc(secret_gray, ext)
            ext_display = _upscale(ext, cover.shape)

            attack_results[ak] = {
                'name': aname,
                'attacked_image': _to_b64(attacked),
                'extracted': _to_b64(ext_display),
                'ncc': round(ncc_val, 4),
                'attacked_psnr': round(calculate_psnr(container, attacked), 2)
            }

        diff = cv2.absdiff(cover.astype(np.float32), container.astype(np.float32))
        diff = (diff * 20).clip(0, 255).astype(np.uint8)

        return jsonify({
            'success': True,
            'container': _to_b64(container),
            'extracted_before': _to_b64(_upscale(extracted_raw, cover.shape)),
            'diff_map': _to_b64(diff),
            'hide_metrics': {
                'psnr': round(hide_psnr, 2),
                'ssim': round(hide_ssim, 4),
                'ncc_before': round(ncc_before, 4),
                'blind': is_blind
            },
            'attack_results': attack_results
        })
    except Exception as e:
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)

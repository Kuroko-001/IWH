"""
基于可逆神经网络的图中藏图 (简化版 HiNet 思路)

核心思想：
- 使用 Haar 小波变换构建可逆的下采样/上采样
- 耦合层 (Coupling Layer) 保证前向和反向都是可逆的
- 前向：封面图 + 秘密图 → 容器图 (看起来像封面)
- 反向：容器图 → 恢复秘密图

架构参考: HiNet (ICCV 2021) — Deep Image Hiding by Invertible Network
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import cv2


# ═══════════════════════════════════════════════════════════
#  小波变换层 (可逆，代替 HiNet 中的 InvBlock)
# ═══════════════════════════════════════════════════════════

def haar_wavelet_transform(x: torch.Tensor) -> tuple:
    """
    Haar 小波正变换：将 (B, C, H, W) 分解为 (B, 4C, H/2, W/2)
    返回 (LL, LH, HL, HH) 四个子带拼接
    """
    B, C, H, W = x.shape
    # 确保 H, W 为偶数
    H_even = H - H % 2
    W_even = W - W % 2
    x = x[:, :, :H_even, :W_even]

    x_reshaped = x.reshape(B * C, 1, H_even, W_even)

    # Haar 小波核
    LL = F.avg_pool2d(x_reshaped, kernel_size=2, stride=2) * 2
    # 使用差分近似小波系数
    x_down = F.interpolate(x_reshaped, scale_factor=0.5, mode='bilinear', align_corners=False)
    diff = x_reshaped - F.interpolate(x_down, scale_factor=2.0, mode='bilinear', align_corners=False)

    # 将差分分解为 LH, HL, HH
    LH = F.avg_pool2d(diff[:, :, :, ::2], kernel_size=(2, 1), stride=(2, 1)) * 2
    HL = F.avg_pool2d(diff[:, :, ::2, :], kernel_size=(1, 2), stride=(1, 2)) * 2
    HH = F.avg_pool2d(diff[:, :, ::2, ::2], kernel_size=2, stride=2) * 2

    # Reshape back
    _, _, H_half, W_half = LL.shape
    LL = LL.reshape(B, C, H_half, W_half)
    LH = LH.reshape(B, C, H_half, W_half)
    HL = HL.reshape(B, C, H_half, W_half)
    HH = HH.reshape(B, C, H_half, W_half)

    return LL, LH, HL, HH


def inverse_haar_wavelet(LL: torch.Tensor, LH: torch.Tensor,
                         HL: torch.Tensor, HH: torch.Tensor,
                         orig_h: int, orig_w: int) -> torch.Tensor:
    """
    Haar 小波逆变换：从四个子带重建原始图像
    简化版：使用双线性插值近似重建
    """
    # 拼接子带
    combined = torch.cat([LL, LH, HL, HH], dim=1)  # (B, 4C, H/2, W/2)
    # 上采样重建
    reconstructed = F.interpolate(combined, size=(orig_h, orig_w),
                                  mode='bilinear', align_corners=False)
    # 通道压缩
    B = LL.shape[0]
    C_in = LL.shape[1]
    result = reconstructed[:, :C_in, :, :]
    return result


# ═══════════════════════════════════════════════════════════
#  可逆耦合层
# ═══════════════════════════════════════════════════════════

class DenseBlock(nn.Module):
    """密集连接块，用于耦合层中的变换函数"""
    def __init__(self, in_channels: int, out_channels: int):
        super().__init__()
        self.conv1 = nn.Conv2d(in_channels, 32, 3, padding=1)
        self.conv2 = nn.Conv2d(32, 32, 3, padding=1)
        self.conv3 = nn.Conv2d(32, 32, 3, padding=1)
        self.conv4 = nn.Conv2d(64, 32, 3, padding=1)
        self.conv5 = nn.Conv2d(96, 32, 3, padding=1)
        self.conv_out = nn.Conv2d(128, out_channels, 3, padding=1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x1 = F.leaky_relu(self.conv1(x), 0.1)
        x2 = F.leaky_relu(self.conv2(x1), 0.1)
        x3 = F.leaky_relu(self.conv3(x2), 0.1)
        x4 = F.leaky_relu(self.conv4(torch.cat([x1, x3], dim=1)), 0.1)
        x5 = F.leaky_relu(self.conv5(torch.cat([x1, x2, x4], dim=1)), 0.1)
        return self.conv_out(torch.cat([x1, x2, x3, x5], dim=1))


class InvCouplingLayer(nn.Module):
    """
    可逆耦合层 (仿射耦合)
    前向: y1 = x1 + F(x2), y2 = x2 + G(y1)
    反向: x2 = y2 - G(y1), x1 = y1 - F(x2)
    """
    def __init__(self, channels: int):
        super().__init__()
        half_c = channels // 2
        self.F = DenseBlock(half_c, half_c)
        self.G = DenseBlock(half_c, half_c)

    def forward(self, x: torch.Tensor, reverse: bool = False) -> torch.Tensor:
        C = x.shape[1]
        x1, x2 = x[:, :C//2], x[:, C//2:]

        if not reverse:
            y1 = x1 + self.F(x2)
            y2 = x2 + self.G(y1)
        else:
            y2 = x2
            y1 = x1
            y2 = y2 - self.G(y1)
            y1 = y1 - self.F(x2)
            # Reorder for reverse
            y1, y2 = y2, y1

        return torch.cat([y1, y2], dim=1)


class InvBlock(nn.Module):
    """可逆块 = Haar小波 + 耦合层"""
    def __init__(self, channels: int):
        super().__init__()
        self.coupling = InvCouplingLayer(channels * 4)

    def forward(self, x: torch.Tensor, reverse: bool = False) -> torch.Tensor:
        if not reverse:
            LL, LH, HL, HH = haar_wavelet_transform(x)
            wavelet_cat = torch.cat([LL, LH, HL, HH], dim=1)
            transformed = self.coupling(wavelet_cat)
            return transformed
        else:
            B = x.shape[0]
            transformed = self.coupling(x, reverse=True)
            C4 = transformed.shape[1]
            C = C4 // 4
            LL = transformed[:, :C]
            LH = transformed[:, C:2*C]
            HL = transformed[:, 2*C:3*C]
            HH = transformed[:, 3*C:4*C]
            return inverse_haar_wavelet(LL, LH, HL, HH, 0, 0)


# ═══════════════════════════════════════════════════════════
#  HiNet 简化版 — 图中藏图网络
# ═══════════════════════════════════════════════════════════

class SimpleHiNet(nn.Module):
    """
    简化版 HiNet 可逆网络
    前向: 封面 + 秘密 → 容器图 + 随机潜变量
    反向: 容器图 → 封面 + 秘密
    """
    def __init__(self, in_channels: int = 3, num_blocks: int = 4):
        super().__init__()
        self.in_channels = in_channels
        # 输入: 封面+秘密 = 6通道
        self.prep_conv = nn.Conv2d(in_channels * 2, 32, 3, padding=1)
        self.blocks = nn.ModuleList([InvBlock(8) for _ in range(num_blocks)])
        self.post_conv = nn.Conv2d(32, in_channels, 3, padding=1)

    def forward(self, cover: torch.Tensor, secret: torch.Tensor) -> torch.Tensor:
        """前向: 隐藏秘密图到封面中，返回容器图"""
        B, C, H, W = cover.shape
        # 确保偶数尺寸
        H_new = H - H % (2 ** len(self.blocks))
        W_new = W - W % (2 ** len(self.blocks))
        cover = F.interpolate(cover, size=(H_new, W_new), mode='bilinear', align_corners=False)
        secret = F.interpolate(secret, size=(H_new, W_new), mode='bilinear', align_corners=False)

        x = torch.cat([cover, secret], dim=1)
        x = F.leaky_relu(self.prep_conv(x), 0.1)

        for block in self.blocks:
            x = block(x)

        container = self.post_conv(x[:, :self.in_channels * 4])
        container = F.interpolate(container, size=(H, W), mode='bilinear', align_corners=False)
        return torch.tanh(container)

    def reverse(self, container: torch.Tensor) -> torch.Tensor:
        """反向: 从容器图恢复秘密图"""
        B, C, H, W = container.shape
        H_new = H - H % (2 ** len(self.blocks))
        W_new = W - W % (2 ** len(self.blocks))
        container = F.interpolate(container, size=(H_new, W_new), mode='bilinear', align_corners=False)

        x = self.prep_conv(torch.cat([container, torch.zeros_like(container)], dim=1))
        x = F.leaky_relu(x, 0.1)

        for block in reversed(self.blocks):
            x = block(x, reverse=True)

        secret = self.post_conv(x[:, self.in_channels * 4:])
        secret = F.interpolate(secret, size=(H, W), mode='bilinear', align_corners=False)
        return torch.tanh(secret)


# ═══════════════════════════════════════════════════════════
#  频域混合隐藏法 (传统但效果好的方法)
# ═══════════════════════════════════════════════════════════

def frequency_blend_hide(cover: np.ndarray, secret: np.ndarray, alpha: float = 0.05) -> np.ndarray:
    """
    频域混合隐藏: 在 DCT 域将秘密图的高频信息嵌入到封面图中
    这比简单的 LSB 更难被检测
    """
    if cover.ndim == 3:
        cover_ycrcb = cv2.cvtColor(cover, cv2.COLOR_BGR2YCrCb)
        cover_Y = cover_ycrcb[:, :, 0].astype(np.float32)
    else:
        cover_Y = cover.astype(np.float32)

    if secret.ndim == 3:
        secret_gray = cv2.cvtColor(secret, cv2.COLOR_BGR2GRAY).astype(np.float32)
    else:
        secret_gray = secret.astype(np.float32)

    H, W = cover_Y.shape
    secret_resized = cv2.resize(secret_gray, (W, H))

    # DCT 变换
    cover_dct = cv2.dct(cover_Y)
    secret_dct = cv2.dct(secret_resized)

    # 在高频区域嵌入秘密图
    result_dct = cover_dct.copy()
    h_cut = H // 4
    w_cut = W // 4
    result_dct[h_cut:, w_cut:] += alpha * secret_dct[h_cut:, w_cut:]

    # 逆 DCT
    result_Y = cv2.idct(result_dct)
    result_Y = np.clip(result_Y, 0, 255).astype(np.uint8)

    if cover.ndim == 3:
        cover_ycrcb[:, :, 0] = result_Y
        return cv2.cvtColor(cover_ycrcb, cv2.COLOR_YCrCb2BGR)
    return result_Y


def frequency_blend_extract(cover: np.ndarray, container: np.ndarray, alpha: float = 0.05) -> np.ndarray:
    """从频域混合图像中提取秘密图"""
    if cover.ndim == 3:
        cover_ycrcb = cv2.cvtColor(cover, cv2.COLOR_BGR2YCrCb)
        cover_Y = cover_ycrcb[:, :, 0].astype(np.float32)
        container_ycrcb = cv2.cvtColor(container, cv2.COLOR_BGR2YCrCb)
        container_Y = container_ycrcb[:, :, 0].astype(np.float32)
    else:
        cover_Y = cover.astype(np.float32)
        container_Y = container.astype(np.float32)

    H, W = cover_Y.shape

    cover_dct = cv2.dct(cover_Y)
    container_dct = cv2.dct(container_Y)

    # 提取高频差异
    h_cut = H // 4
    w_cut = W // 4
    diff = container_dct - cover_dct
    extracted_dct = np.zeros_like(diff)
    extracted_dct[h_cut:, w_cut:] = diff[h_cut:, w_cut:] / alpha

    extracted = cv2.idct(extracted_dct)
    extracted = np.abs(extracted)
    extracted = (extracted / extracted.max() * 255) if extracted.max() > 0 else extracted
    extracted = np.clip(extracted, 0, 255).astype(np.uint8)
    return extracted
